# frozen_string_literal: true

require 'rails_helper'

# Specs for the RBAC permission split (tech-spec rbac-granular-inbox-permissions).
#
#   - users.read / inboxes.read were removed from BASIC_READ_PERMISSIONS so they
#     no longer leak to every user (the dual-semantics bug).
#   - A role with conversations.read now receives users.read / inboxes.read
#     OPERATIONALLY (OPERATIONAL_IMPLICATIONS) so the Conversations screen keeps
#     working for a profile created AFTER the split — covers AC6 / AC6b.
#   - The implication must show up in BOTH has_permission? (API enforcement) and
#     all_permissions (read by the frontend PermissionsContext) so FE and BE
#     agree.
RSpec.describe User, type: :model do
  def build_user(email: nil)
    User.create!(
      name: 'Perm User',
      email: email || "perm-#{SecureRandom.hex(4)}@example.com",
      password: 'Valid1!Pass',
      password_confirmation: 'Valid1!Pass',
      confirmed_at: Time.current
    )
  end

  def role_with(*permission_keys, key: "role-#{SecureRandom.hex(4)}", type: 'account')
    role = Role.create!(key: key, name: key.titleize, type: type, system: false)
    permission_keys.each { |pk| role.role_permissions_actions.create!(permission_key: pk) }
    role
  end

  def assign(user, role)
    UserRole.assign_role_to_user(user, role)
  end

  describe 'BASIC_READ_PERMISSIONS no longer leaks users.read / inboxes.read' do
    it 'does not include users.read or inboxes.read' do
      expect(User::BASIC_READ_PERMISSIONS).not_to include('users.read')
      expect(User::BASIC_READ_PERMISSIONS).not_to include('inboxes.read')
    end

    it 'still includes the kept basic reads' do
      expect(User::BASIC_READ_PERMISSIONS).to include('accounts.read', 'labels.read', 'dashboard.read', 'teams.read')
    end

    it 'a user with no roles does NOT have users.read via inheritance' do
      user = build_user
      expect(user.has_permission?('users.read')).to be(false)
      expect(user.all_permissions).not_to include('users.read')
      expect(user.all_permissions).not_to include('inboxes.read')
    end
  end

  describe 'operational implication: conversations.read => users.read + inboxes.read' do
    let(:user) { build_user }

    before { assign(user, role_with('conversations.read')) }

    it 'has_permission?(users.read) is true (operational, AC6)' do
      expect(user.has_permission?('users.read')).to be(true)
    end

    it 'has_permission?(inboxes.read) is true (operational)' do
      expect(user.has_permission?('inboxes.read')).to be(true)
    end

    it 'all_permissions includes the implied reads so the frontend agrees (AC6b)' do
      expect(user.all_permissions).to include('users.read', 'inboxes.read', 'conversations.read')
    end

    it 'does NOT imply users.manage (administrative gate stays closed)' do
      expect(user.has_permission?('users.manage')).to be(false)
      expect(user.all_permissions).not_to include('users.manage')
    end
  end

  describe 'no implication without conversations.read' do
    let(:user) { build_user }

    before { assign(user, role_with('contacts.read')) }

    it 'does not grant users.read just from an unrelated role permission' do
      expect(user.has_permission?('users.read')).to be(false)
      expect(user.all_permissions).not_to include('users.read')
    end
  end

  describe 'explicit role permission still resolves' do
    let(:user) { build_user }

    before { assign(user, role_with('users.manage')) }

    it 'has_permission? returns true for an explicitly granted key' do
      expect(user.has_permission?('users.manage')).to be(true)
      expect(user.all_permissions).to include('users.manage')
    end
  end
end

RSpec.describe ResourceActionsConfig, type: :model do
  describe '.valid_permission? for the new keys' do
    it 'recognises users.manage' do
      expect(described_class.valid_permission?('users.manage')).to be(true)
    end

    it 'recognises conversations.read_all' do
      expect(described_class.valid_permission?('conversations.read_all')).to be(true)
    end

    it 'still rejects a bogus key' do
      expect(described_class.valid_permission?('users.does_not_exist')).to be(false)
    end
  end
end
