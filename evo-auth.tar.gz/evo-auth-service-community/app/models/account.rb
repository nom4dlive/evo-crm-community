# == Schema Information
#
# Table name: accounts
#
#  id            :uuid             not null, primary key
#  name          :string           not null
#  slug          :string           not null
#  domain        :string
#  locale        :string           default("pt-BR")
#  status        :string           not null, default("active")
#  settings      :jsonb            default({})
#  limits        :jsonb            default({})
#  features      :jsonb            default({})
#  plan_id       :uuid
#  trial_ends_at :datetime
#  created_at    :datetime         not null
#  updated_at    :datetime         not null
#
# Indexes
#
#  index_accounts_on_slug    (slug) UNIQUE
#  index_accounts_on_domain  (domain) UNIQUE WHERE domain IS NOT NULL
#  index_accounts_on_status  (status)
#

class Account < ApplicationRecord
  # Associations
  has_many :users, dependent: :destroy
  has_many :user_roles, dependent: :destroy
  has_many :access_tokens, dependent: :destroy
  has_many :data_privacy_consents, dependent: :destroy

  # Validations
  validates :name, presence: true, length: { maximum: 255 }
  validates :slug, presence: true, uniqueness: true, length: { maximum: 100 },
                   format: { with: /\A[a-z0-9]([a-z0-9\-]*[a-z0-9])?\z/,
                             message: 'must contain only lowercase letters, numbers, and hyphens' }
  validates :status, presence: true, inclusion: { in: %w[active suspended trial] }
  validates :domain, uniqueness: true, allow_blank: true
  validates :locale, length: { maximum: 10 }

  # Scopes
  scope :active, -> { where(status: 'active') }
  scope :suspended, -> { where(status: 'suspended') }
  scope :trial, -> { where(status: 'trial') }

  # Callbacks
  before_validation :normalize_slug, on: :create

  def active?
    status == 'active'
  end

  def suspended?
    status == 'suspended'
  end

  def trial?
    status == 'trial'
  end

  def trial_expired?
    trial? && trial_ends_at.present? && trial_ends_at < Time.current
  end

  # Feature flag helpers
  def feature_enabled?(feature_key)
    features.fetch(feature_key.to_s, false)
  end

  # Limit helpers
  def limit_for(resource_key)
    limits.fetch(resource_key.to_s, nil)
  end

  def setting(key, default = nil)
    settings.fetch(key.to_s, default)
  end

  def to_dict
    {
      id: id,
      name: name,
      slug: slug,
      domain: domain,
      locale: locale,
      status: status,
      settings: settings,
      features: features,
      limits: limits,
      trial_ends_at: trial_ends_at&.iso8601,
      created_at: created_at&.iso8601,
      updated_at: updated_at&.iso8601
    }
  end

  private

  def normalize_slug
    return if slug.present?

    base_slug = name.to_s.parameterize
    self.slug = base_slug

    # Ensure uniqueness
    counter = 1
    while Account.exists?(slug: self.slug)
      self.slug = "#{base_slug}-#{counter}"
      counter += 1
    end
  end
end
