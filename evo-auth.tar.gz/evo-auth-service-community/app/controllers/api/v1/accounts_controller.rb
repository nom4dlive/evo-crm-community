# frozen_string_literal: true

module Api
  module V1
    class AccountsController < ApplicationController
      before_action :require_super_admin!
      before_action :set_account, only: [:show, :update, :destroy]

      # GET /api/v1/accounts
      def index
        accounts = Account.all.order(created_at: :desc)
        render json: { data: accounts.map(&:to_dict) }
      end

      # GET /api/v1/accounts/:id
      def show
        render json: { data: @account.to_dict }
      end

      # POST /api/v1/accounts
      def create
        account = Account.new(account_params)

        if account.save
          render json: { data: account.to_dict }, status: :created
        else
          render json: { errors: account.errors.full_messages }, status: :unprocessable_entity
        end
      end

      # PATCH /api/v1/accounts/:id
      def update
        if @account.update(account_params)
          render json: { data: @account.to_dict }
        else
          render json: { errors: @account.errors.full_messages }, status: :unprocessable_entity
        end
      end

      # DELETE /api/v1/accounts/:id
      def destroy
        @account.update!(status: 'suspended')
        render json: { message: 'Account suspended successfully' }
      end

      private

      def set_account
        @account = Account.find(params[:id])
      end

      def account_params
        params.require(:account).permit(
          :name, :slug, :domain, :locale, :status, :plan_id, :trial_ends_at,
          settings: {}, limits: {}, features: {}
        )
      end

      def require_super_admin!
        return if current_user&.has_role?('super_admin')

        render json: { error: 'Forbidden: super_admin role required' }, status: :forbidden
      end
    end
  end
end
