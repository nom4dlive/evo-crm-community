# frozen_string_literal: true

class AddAccountIdToAuthTables < ActiveRecord::Migration[7.1]
  def up
    # Add account_id to users
    unless column_exists?(:users, :account_id)
      add_column :users, :account_id, :uuid
      add_index :users, :account_id, if_not_exists: true
      add_index :users, [:account_id, :email], unique: true, name: 'index_users_on_account_id_and_email', if_not_exists: true
    end

    # Add account_id to access_tokens
    unless column_exists?(:access_tokens, :account_id)
      add_column :access_tokens, :account_id, :uuid
      add_index :access_tokens, :account_id, if_not_exists: true
    end

    # Add account_id to user_roles
    unless column_exists?(:user_roles, :account_id)
      add_column :user_roles, :account_id, :uuid
      add_index :user_roles, :account_id, if_not_exists: true
    end

    # Add account_id to data_privacy_consents
    unless column_exists?(:data_privacy_consents, :account_id)
      add_column :data_privacy_consents, :account_id, :uuid
      add_index :data_privacy_consents, :account_id, if_not_exists: true
    end

    # Add account_id to setup_survey_responses
    if table_exists?(:setup_survey_responses) && !column_exists?(:setup_survey_responses, :account_id)
      add_column :setup_survey_responses, :account_id, :uuid
      add_index :setup_survey_responses, :account_id, if_not_exists: true
    end

    # Add foreign keys (nullable for backward compatibility during migration)
    add_fk_if_missing(:users, :accounts, :account_id)
    add_fk_if_missing(:access_tokens, :accounts, :account_id)
    add_fk_if_missing(:user_roles, :accounts, :account_id)
    add_fk_if_missing(:data_privacy_consents, :accounts, :account_id)
  end

  def down
    remove_column :users, :account_id if column_exists?(:users, :account_id)
    remove_column :access_tokens, :account_id if column_exists?(:access_tokens, :account_id)
    remove_column :user_roles, :account_id if column_exists?(:user_roles, :account_id)
    remove_column :data_privacy_consents, :account_id if column_exists?(:data_privacy_consents, :account_id)
    remove_column :setup_survey_responses, :account_id if table_exists?(:setup_survey_responses) && column_exists?(:setup_survey_responses, :account_id)
  end

  private

  def add_fk_if_missing(from_table, to_table, column)
    return unless table_exists?(to_table)
    return if foreign_key_exists?(from_table, to_table, column: column)

    add_foreign_key from_table, to_table, column: column, on_delete: :cascade
  rescue => e
    say "Skipping FK #{from_table}.#{column} → #{to_table}: #{e.message}"
  end
end
