# frozen_string_literal: true

class CreateAccounts < ActiveRecord::Migration[7.1]
  def up
    create_table :accounts, id: :uuid, default: -> { "gen_random_uuid()" }, if_not_exists: true do |t|
      t.string   :name,     null: false
      t.string   :slug,     null: false
      t.string   :domain
      t.string   :locale,   default: 'pt-BR'
      t.string   :status,   null: false, default: 'active' # active, suspended, trial
      t.jsonb    :settings,  default: {}
      t.jsonb    :limits,    default: {} # rate limits, max instances, etc.
      t.jsonb    :features,  default: {} # feature flags per tenant
      t.uuid     :plan_id
      t.datetime :trial_ends_at
      t.timestamps default: -> { 'NOW()' }, null: false
    end

    add_index :accounts, :slug, unique: true, if_not_exists: true
    add_index :accounts, :domain, unique: true, where: "domain IS NOT NULL AND domain != ''", if_not_exists: true
    add_index :accounts, :status, if_not_exists: true
    add_index :accounts, :plan_id, if_not_exists: true
  end

  def down
    drop_table :accounts, if_exists: true
  end
end
